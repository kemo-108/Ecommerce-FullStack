import "./Sidebar.css";
import {
  FaHome,
  FaBoxOpen,
  FaShoppingCart,
  FaUsers,
  FaChartBar,
  FaCog,
  FaSignOutAlt,
  FaTags,
  FaTicketAlt,
  FaWarehouse,
  FaUndoAlt,
  FaFileInvoiceDollar,
} from "react-icons/fa";
import { FiLogOut } from "react-icons/fi";
import { Link, NavLink, useNavigate } from "react-router-dom";
import {
  GetCurrentUser,
  Logout,
  ClearSession,
} from "../../../services/AuthService";
import { toast } from "react-toastify";

const Sidebar = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await Logout();
    } catch (error) {
      console.error(error);
    } finally {
      ClearSession();
      toast.success("Logged out successfully");
      navigate("/login");
    }
  };
  return (
    <aside className="admin-sidebar">
      <div className="sidebar-logo">
        <Link to="/" className="sidebar-home-link">
          Home
        </Link>
        <span> &gt; Admin</span>
      </div>

      <NavLink
        to="/admin/dashboard"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaHome />
        <span>Dashboard</span>
      </NavLink>

      <NavLink
        to="/admin/products"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaBoxOpen />
        <span>Products</span>
      </NavLink>

      <NavLink
        to="/admin/orders"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaShoppingCart />
        <span>Orders</span>
      </NavLink>
      <NavLink
        to="/admin/Refunds"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaUndoAlt />
        <span>Refunds</span>
      </NavLink>

      <NavLink
        to="/admin/customers"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaUsers />
        <span>Customers</span>
      </NavLink>

      <NavLink
        to="/admin/category"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaTags />
        <span>Category</span>
      </NavLink>

      <NavLink
        to="/admin/coupons"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaTicketAlt />
        <span>Coupons</span>
      </NavLink>

      <NavLink
        to="/admin/inventory"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaWarehouse />
        <span>Inventory</span>
      </NavLink>

      <NavLink
        to="/admin/reports"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaChartBar />
        <span>Reports</span>
      </NavLink>

      <NavLink
        to="/admin/accounting"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaFileInvoiceDollar />
        <span>Accounting</span>
      </NavLink>

      <NavLink
        to="/admin/settings"
        className={({ isActive }) =>
          isActive ? "sidebar-link active" : "sidebar-link"
        }
      >
        <FaCog />
        <span>Settings</span>
      </NavLink>

      <button className="logout-btn" onClick={handleLogout}>
        <FiLogOut />
        <span>Logout</span>
      </button>
    </aside>
  );
};

export default Sidebar;
